from .singleton import Singleton
