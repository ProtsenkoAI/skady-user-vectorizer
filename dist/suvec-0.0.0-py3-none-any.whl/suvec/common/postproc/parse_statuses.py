ParseStatus = int
SuccessParseStatus = 0
AccessErrorStatus = 1
UnknownStatus = 2
