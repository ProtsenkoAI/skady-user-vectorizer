from .singleton import Singleton, AbstractSingleton
