from typing import NamedTuple


User = NamedTuple("User", [("id", str)])
Group = NamedTuple("Group", [("id", str)])
