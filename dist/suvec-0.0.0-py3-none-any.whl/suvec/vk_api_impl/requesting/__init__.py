from .requests_creator import VkApiRequestsCreator
from .requests import GroupsRequest, FriendsRequest
